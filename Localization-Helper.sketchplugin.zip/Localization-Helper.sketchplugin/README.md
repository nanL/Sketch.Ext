# Localization Helper

双击 `Localization-Helper.sketchplugin` 安装，在 Sketch 的插件菜单中打开「Localization Helper → 设置」，填写百度通用文本翻译 API 的 AppID 和 Secret。

选择一个或多个文本图层，执行对应菜单：

- to 简体
- to 繁体
- to 英文
- 设置

三个翻译菜单均使用 `from=auto` 自动识别原文语种，目标语种分别为 `zh`、`cht`、`en`。

仅处理直接选中的非空文本图层，不递归处理组。译文通过 Sketch 的 `Text.text` 接口一次替换，样式保留行为由 Sketch 处理，不强制统一混合样式。所有选中文本用固定分隔符 `␞`（U+241E） 拼接后只请求一次，不区分单行、多行，不按长度分批，也不逐图层重试。译文按同一分隔符拆分，数量与图层数一致才回填；请求失败、数量不匹配或原文已修改时保留原文。原文本身包含 `␞` 或百度改写分隔符可能导致分段不匹配。百度可能调整译文的换行。

凭证保存在本机 Sketch 插件设置中，Secret 输入框使用遮罩显示；设置存储本身不是加密保险库。源码不包含凭证。选中文本通过 HTTPS 发送至百度，调用额度及费用以对应百度账号为准。

分段数量不匹配时，弹窗会显示本次请求的完整原文和译文，便于检查分隔符是否被改写。

请求使用百度通用翻译接口与 UTF-8 MD5 签名。网络请求通过 macOS 自带的 `/usr/bin/curl` 执行，使用 Sketch 定时器检查完成状态，避免 JavaScript 回调到原生 Objective-C block 的桥接问题。响应临时文件在完成或取消后删除，无第三方依赖。

## 在线更新

Sketch 通过 `manifest.json` 中的 `appcast` 地址检查更新，下载仓库 `main` 分支中的 `Localization-Helper.sketchplugin.zip`。发布新版本时，需同步更新 manifest 和 `appcast.xml` 的版本号、重新生成 ZIP，并将这些文件一并推送到 `main`。首次启用在线更新需安装包含此配置的版本。

`tests` 为开发回归测试，保留在源码目录，不包含在发布 ZIP 中。运行方式：

```sh
node Localization-Helper.sketchplugin/tests/commands.test.js
```
